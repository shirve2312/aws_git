# javalin-rest
Simple Javalin  REST app. Used in AWS Fargate tutorial. Uses Github Actions to deploy to ECS.

https://www.awstutorials.cloud/
